﻿
export const columns = [
{ dataIndex: 'creator_id',key: 'creator_id', title: 'creator_id' }, { dataIndex: 'editor_id',key: 'editor_id', title: 'editor_id' }, { dataIndex: 'edit_date',key: 'edit_date', title: 'edit_date' }, { dataIndex: 'create_date',key: 'create_date', title: 'create_date' }, { dataIndex: 'current_user_id',key: 'current_user_id', title: 'current_user_id' }, { dataIndex: 'status',key: 'status', title: 'status' }, { dataIndex: 'contract_id',key: 'contract_id', title: 'contract_id' }, { dataIndex: 'insurance_id',key: 'insurance_id', title: 'insurance_id' }, { dataIndex: 'start_date',key: 'start_date', title: 'start_date' }, { dataIndex:
'end_date',key: 'end_date', title: 'end_date' }, { dataIndex: 'price',key: 'price', title: 'price' },
];
export const storeIndex = "insuranceAppendix";
export const pageHeder = 'الحاقیه بیمه';

export const emptyItem = {
 contract_id : '' ,insurance_id : '' ,start_date : '' ,end_date : '' ,price : '' ,
};